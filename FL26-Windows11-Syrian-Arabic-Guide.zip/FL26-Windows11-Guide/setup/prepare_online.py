"""Prepare a PRIVATE FL26 online copy. No downloads or hosts changes.

Experimental Windows adaptation of a configuration tested under Wine on Linux.
Only the exact verified FL26 2.2 executable is supported. No game files are shipped.
"""
from pathlib import Path
import configparser
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

from cpk_reader import entries

SOURCE_SHA = '9ee0c30651e5e3c37e3d308fb8224f5fea135cd8e929dee2cddca6e041836281'
PATCHED_SHA = '8fefd36ed9643f736bace53241a214b167a851bc5f903465c33ad85d277254f4'
PATCH_OFFSET = 0xbc9496
HERE = Path(__file__).resolve().parent
FLOW_CHANGES = {
    'common/script/flow/Intro/IntroLoginFlow.json': {
        '0_topmenu': 'Online/Login/LoginFlow',
        '1_konamiid': 'Online/Login/LoginFlow',
    },
    'common/script/flow/TopMenu/TopMenuNew.json': {
        '17_edit': 'TopMenu/TopMenuModeInit',
        '19_replaygallery': 'Online/Login/LoginFlow',
    },
    'common/script/flow/TopMenu/TopMenuModeInit.json': {
        '1_mode_online': 'Online/Login/LoginFlow',
    },
    'common/script/flow/Online/Login/LoginFlow.json': {},
}


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def make_flows(source):
    result = {}
    tables = {}
    for name, changes in FLOW_CHANGES.items():
        archive = source / 'Data' / ('dt00_x64.cpk' if '/Intro/' in name else 'dt16_all.cpk')
        if archive not in tables:
            tables[archive] = {e['path']: e for e in entries(archive)}
        entry = tables[archive][name]
        with archive.open('rb') as f:
            f.seek(entry['absolute_offset'])
            obj = json.loads(f.read(entry['FileSize']))
        for event, destination in changes.items():
            obj['events'][event]['to'] = destination
        result[name] = json.dumps(obj, indent=2)
    return result


def validate_source(source):
    needed = ['FL_2026.exe', 'sys.ini', 'FL 2026 start.exe',
              'SiderAddons/sider.exe', 'SiderAddons/sider.dll',
              'Data/dt00_x64.cpk', 'Data/dt16_all.cpk']
    for name in needed:
        if not (source / name).is_file():
            raise ValueError('Wrong game folder; missing: ' + name)
    if sha(source / 'FL_2026.exe') != SOURCE_SHA:
        raise ValueError('UNSUPPORTED GAME BUILD. Install official FL26 update 2.0, then 2.2. '
                         'This tool refuses to patch another executable. Do not rename a different file.')
    return make_flows(source)


def patch_executable(path):
    if sha(path) != SOURCE_SHA:
        raise ValueError('Unexpected executable before patch')
    with path.open('r+b') as f:
        f.seek(PATCH_OFFSET)
        if f.read(4) != bytes.fromhex('00000100'):
            raise ValueError('Unexpected initialization instruction')
        f.seek(PATCH_OFFSET)
        f.write(bytes.fromhex('00ef0100'))
    if sha(path) != PATCHED_SHA:
        raise ValueError('Executable verification failed')


def steam_identity():
    import winreg
    candidates = []
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Valve\Steam') as key:
            candidates.append(Path(winreg.QueryValueEx(key, 'SteamPath')[0]))
    except OSError:
        pass
    candidates.append(Path(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')) / 'Steam')
    for base in candidates:
        file = base / 'config/loginusers.vdf'
        if not file.is_file():
            continue
        text = file.read_text(encoding='utf-8', errors='replace')
        for match in re.finditer(r'"(7656119\d{10})"\s*\{([^{}]*)\}', text):
            if re.search(r'"MostRecent"\s*"1"', match[2]):
                return match[1]
    raise ValueError('Steam identity not found. Install Steam, sign in to YOUR OWN account, '
                     'close this setup, then run it again. Do not use another person\'s sys.ini.')


def write_config(target, flows, identity, name):
    patch_executable(target / 'FL_2026.exe')
    ini = configparser.ConfigParser(interpolation=None)
    ini.optionxform = str
    ini.read(target / 'sys.ini', encoding='utf-8-sig')
    if ini.get('Settings', 'SteamID', fallback='') == identity:
        raise ValueError('Source already uses this Steam identity. Choose an untouched FL26 installation '
                         'so the online profile remains separate.')
    ini['Settings']['SteamID'] = identity
    ini['Settings']['PlayerName'] = name
    ini['Settings']['SavePath'] = '%DEFAULT_SYS_DIR%'
    with (target / 'sys.ini').open('w', encoding='utf-8') as f:
        ini.write(f, space_around_delimiters=False)
    sider = target / 'SiderAddons'
    (sider / 'modules').mkdir(exist_ok=True)
    shutil.copy2(HERE / 'online-mode.lua', sider / 'modules/online-mode.lua')
    # Do not retain an enabled trainer or other Lua module from the offline copy.
    (sider / 'sider.ini').write_text(
        '[sider]\ndebug = 1\nclose.on.exit = 1\nstart.minimized = 1\n'
        'exe.name = "\\FL_2026.exe"\nlivecpk.enabled = 1\n'
        'cpk.root = ".\\livecpk\\online-diagnostic"\nlua.enabled = 1\n'
        'lua.module = "online-mode.lua"\noverlay.enabled = 0\n', encoding='utf-8')
    override = sider / 'livecpk/online-diagnostic'
    # This destination is a newly created copy, never the source.
    if override.exists():
        shutil.rmtree(override)
    for name, content in flows.items():
        file = override / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(content, encoding='utf-8')
    (target / 'START-ONLINE.cmd').write_text(
        '@echo off\r\ncd /d "%~dp0"\r\nstart "" "FL 2026 start.exe"\r\n', encoding='ascii')
    (target / 'ONLINE-SETUP-README.txt').write_text(
        'EXPERIMENTAL WINDOWS ADAPTATION - NOT WINDOWS-VALIDATED\n'
        'Start: START-ONLINE.cmd or FL 2026 start.exe in THIS online folder.\n'
        'Route: title > Settings > Edit Mode > Europe > Create Match Room.\n'
        'Both players must select Start Match. Peer-to-peer match remains unverified.\n'
        'Only the online-mode Lua module is enabled. Main game was not modified.\n'
        'PESBUL connector from the official website is a SEPARATE required step.\n', encoding='utf-8')


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--verify-source':
        flows = validate_source(Path(sys.argv[2]))
        print('Verified exact FL26 2.2 source and', len(flows), 'flow files. No files changed.')
        return
    if os.name != 'nt':
        raise SystemExit('This setup UI is for Windows only. --verify-source is read-only and portable.')
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog
    root = tk.Tk()
    root.withdraw()
    try:
        if not messagebox.askokcancel('Experimental FL26 online setup',
                'This is NOT an official PESBUL or SmokePatch installer.\n'
                'The configuration reached rooms on Linux/Wine; Windows and match kickoff are untested.\n'
                'It makes a second game folder and does not edit the original.\n'
                'Close Football Life before continuing. No files will be downloaded.\n\nContinue?'):
            return
        running = subprocess.check_output(['tasklist', '/FI', 'IMAGENAME eq FL_2026.exe', '/FO', 'CSV'],
                                          text=True, errors='replace', creationflags=0x08000000)
        if re.search(r'"FL_2026\.exe"', running, re.I):
            raise ValueError('Close Football Life first, then run this tool again.')
        chosen = filedialog.askdirectory(title='Choose the ORIGINAL FL26 game folder (contains FL_2026.exe)')
        if not chosen:
            return
        source = Path(chosen).resolve()
        flows = validate_source(source)
        identity = steam_identity()
        name = simpledialog.askstring('Online player name', 'Choose a name: 3-16 English letters, numbers or underscores.')
        if name is None:
            return
        if not re.fullmatch(r'[A-Za-z0-9_]{3,16}', name):
            raise ValueError('Name must contain 3-16 English letters, numbers or underscores.')
        target = source.parent / (source.name + ' Online')
        if target.exists():
            raise ValueError('Online folder already exists: ' + str(target) +
                             '\nNothing overwritten. Open its START-ONLINE.cmd, or rename a failed copy before retrying.')
        size = sum(p.stat().st_size for p in source.rglob('*') if p.is_file())
        if shutil.disk_usage(source.parent).free < size + 2 * 1024**3:
            raise ValueError('Not enough space for a full second copy. Need at least ' + str(round(size / 1024**3) + 2) + ' GiB free.')
        if not messagebox.askokcancel('Create separate online copy',
                'Source (unchanged):\n' + str(source) + '\n\nNew copy:\n' + str(target) +
                '\n\nCopy size: approximately ' + str(round(size / 1024**3)) +
                ' GiB. This can take a while. Keep the black window open.\nContinue?'):
            return
        copied = [0, 0]
        def copy_file(src, dst):
            result = shutil.copy2(src, dst)
            copied[0] += Path(src).stat().st_size
            copied[1] += 1
            if copied[1] % 100 == 0 or Path(src).stat().st_size > 1024**3:
                print('Copied', round(copied[0] / 1024**3, 1), '/', round(size / 1024**3, 1), 'GiB', flush=True)
            return result
        shutil.copytree(source, target, copy_function=copy_file)
        write_config(target, flows, identity, name)
        print('SETUP COMPLETE:', target, flush=True)
        messagebox.showinfo('Copy prepared - launch still needs testing',
            'Online copy prepared.\n' + str(target) + '\n\n'
            'Run the official PESBUL connector separately, then launch START-ONLINE.cmd here.\n'
            'Do not apply another game update over this online copy.\n'
            'Windows launch and actual matches still need testing.')
    except Exception as error:
        messagebox.showerror('Setup stopped - original game unchanged', str(error))
        raise
    finally:
        root.destroy()


if __name__ == '__main__':
    main()
