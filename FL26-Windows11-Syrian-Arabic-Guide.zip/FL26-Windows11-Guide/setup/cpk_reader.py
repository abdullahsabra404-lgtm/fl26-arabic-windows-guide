"""Read local CPK tables; never modify game archives."""
from pathlib import Path
import struct
import json

def utf(b):
    assert b[:4] == b'@UTF'
    rows, strings, data = [8 + struct.unpack_from('>I', b, o)[0] for o in (8,12,16)]
    cols, rowlen, count = struct.unpack_from('>HHI', b, 24)
    def string(o):
        start = strings + o
        return b[start:b.index(0,start)].decode('utf-8',errors='replace')
    def value(pos, typ):
        formats={0:'>B',1:'>b',2:'>H',3:'>h',4:'>I',5:'>i',6:'>Q',7:'>q',8:'>f',9:'>d',10:'>I',11:'>II'}
        fmt=formats[typ]; vals=struct.unpack_from(fmt,b,pos)
        v=vals[0] if len(vals)==1 else vals
        if typ==10: v=string(v)
        return v,pos+struct.calcsize(fmt)
    pos=32; schema=[]
    for _ in range(cols):
        flags=b[pos]; name=string(struct.unpack_from('>I',b,pos+1)[0]); pos+=5
        typ=flags&15; storage=flags&0xf0; const=None
        if storage==0x30: const,pos=value(pos,typ)
        schema.append((name,typ,storage,const))
    result=[]
    for i in range(count):
        pos=rows+i*rowlen; row={}
        for name,typ,storage,const in schema:
            if storage==0x50: v,pos=value(pos,typ)
            elif storage==0x30: v=const
            else: v=0
            row[name]=v
        result.append(row)
    return result

def table(h, offset):
    h.seek(offset)
    hdr=h.read(16)
    size=struct.unpack_from('<Q',hdr,8)[0]
    assert size < 100_000_000, size
    return utf(h.read(size))

def entries(path):
    with path.open('rb') as h:
        header=table(h,0)[0]
        toc=table(h,header['TocOffset'])
        base=min(header['TocOffset'],header['ContentOffset'])
        for e in toc:
            e['path']=('/'.join([str(e.get('DirName','')).replace(chr(92),'/').strip('/'), str(e.get('FileName',''))])).lstrip('/')
            e['absolute_offset']=base+e['FileOffset']
        return toc

