local m = {}
local function mode_ready(ctx, filename)
    local path = string.lower(filename):gsub("/", "\\")
    if path == "common\\script\\flow\\topmenu\\topmenumodeinit.json" then
        local manager = memory.unpack("u64", memory.read(0x143704e38, 8))
        if manager == 0 then error("Online mode manager is absent") end
        local before = memory.unpack("u32", memory.read(manager + 0xf0, 4))
        if before < 0 or before > 60 then error("Unexpected game mode value") end
        memory.write(manager + 0xf0, memory.pack("u32", 26))
        log(string.format("Online mode initializer: %d -> ONLINE_LOBBY (26)",before))
    end
end
function m.init(ctx)
    -- The native LiveDataSetFlowOnMode was observed waiting on a blank screen.
    -- Return no local update flow; TaskApplyLiveUpdate retains its native result and
    -- the remaining login/account/menu/server checks.
    local addr = 0x140fdf9d0
    if memory.read(addr, 5) ~= "\x48\x89\x5c\x24\x08" then
        error("Unexpected FL26 LiveData flow selector; refusing patch")
    end
    memory.write(addr, "\x31\xc0\xc3")
    log("Local LiveData flow disabled in online test; native login checks retained")
    ctx.register("livecpk_data_ready",mode_ready)
end
return m
