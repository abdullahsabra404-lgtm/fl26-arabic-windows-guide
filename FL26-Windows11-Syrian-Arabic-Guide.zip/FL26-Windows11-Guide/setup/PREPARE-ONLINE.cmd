@echo off
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
 echo Python 3 is missing. Install Python from python.org as shown in the guide.
 pause
 exit /b 1
)
py -3 prepare_online.py
if errorlevel 1 echo Setup stopped. Read the error above. Original game was not patched.
pause
