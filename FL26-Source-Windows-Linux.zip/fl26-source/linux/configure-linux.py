#!/usr/bin/env python3
"""Apply only the seven DNS mappings from the reviewed official connector."""
import argparse
import json
import os
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
HOSTS = Path('/etc/hosts')
BACKUP = Path('/etc/hosts.before-pesbul-20261024')
START = '# BEGIN PESBUL 2021 connector (Codex)'
END = '# END PESBUL 2021 connector (Codex)'

p = argparse.ArgumentParser()
p.add_argument('action', choices=['install', 'remove'])
args = p.parse_args()
if os.geteuid() != 0:
    raise SystemExit('Run with sudo.')
config = json.loads((HERE / 'connector-config.json').read_text())
original = HOSTS.read_text()
lines = original.splitlines()
filtered = []
inside = False
for line in lines:
    if line == START:
        inside = True
        continue
    if line == END:
        inside = False
        continue
    if not inside:
        filtered.append(line)
if inside:
    raise SystemExit('Unclosed PESBUL block; refusing to edit hosts.')
if args.action == 'install':
    for line in filtered:
        fields = line.split('#', 1)[0].split()
        if len(fields) > 1 and set(fields[1:]) & set(config['domains']):
            raise SystemExit('Existing mapping found; refusing to overwrite: ' + line)
    if not BACKUP.exists():
        shutil.copy2(HOSTS, BACKUP)
    filtered += ['', START]
    filtered += [config['ip'] + ' ' + name for name in config['domains']]
    filtered += [END]
new = '\n'.join(filtered) + '\n'
HOSTS.write_text(new)
assert HOSTS.read_text() == new
print('PESBUL configuration ' + ('installed' if args.action == 'install' else 'removed'))
print('Original hosts backup: ' + str(BACKUP))
print('No game was launched and no server connection was tested.')
