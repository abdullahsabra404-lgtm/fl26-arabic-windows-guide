from pathlib import Path
import re
for p in [Path.home()/'.local/share/Steam/config/loginusers.vdf', Path.home()/'.steam/steam/config/loginusers.vdf']:
    if not p.is_file(): continue
    for m in re.finditer(r'"(7656119\d{10})"\s*\{([^{}]*)\}', p.read_text(errors='replace')):
        if re.search(r'"MostRecent"\s*"1"', m[2]):
            print(m[1]); raise SystemExit(0)
raise SystemExit('Sign into your own Steam account first; no most-recent identity found.')
