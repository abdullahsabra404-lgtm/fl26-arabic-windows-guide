from pathlib import Path
import argparse,re,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'windows'))
from prepare_online import validate_source,write_config
p=argparse.ArgumentParser();p.add_argument('--game',required=True);p.add_argument('--steam-id',required=True);p.add_argument('--name',required=True);a=p.parse_args()
game=Path(a.game).resolve();base=game.parent
if not (base/'.fl26-online-copy').is_file() or not (base/'prefix/system.reg').is_file():raise SystemExit('Refusing target without isolated-copy marker and cloned prefix.')
if not re.fullmatch(r'7656119\d{10}',a.steam_id):raise SystemExit('Expected your own SteamID64.')
if not re.fullmatch(r'[A-Za-z0-9_]{3,16}',a.name):raise SystemExit('Use an ASCII player name, 3-16 characters.')
flows=validate_source(game);write_config(game,flows,a.steam_id,a.name)
print('Isolated copy configured. Native Windows is untested; Linux match kickoff remains unverified.')
