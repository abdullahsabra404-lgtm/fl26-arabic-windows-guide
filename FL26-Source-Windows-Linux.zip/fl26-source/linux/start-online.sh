#!/usr/bin/env bash
set -euo pipefail
ONLINE="${1:?Pass the isolated online directory}"
ONLINE="$(realpath "$ONLINE")"
test -f "$ONLINE/.fl26-online-copy" || { echo 'Missing isolated-copy marker'; exit 1; }
export WINEPREFIX="$ONLINE/prefix"
export WINEDEBUG=-all
export WINEDLLOVERRIDES='ddraw,steam_api64,d3d11,dxgi=n,b;lsteamclient=d'
export ENABLE_GAMESCOPE_WSI=0
export PROTON_USE_XALIA=0
mkdir -p "$ONLINE/logs"
exec 9>"$ONLINE/launch.lock"
flock -n 9 || { echo 'This online copy is already running'; exit 0; }
cd "$ONLINE/game"
runner=()
if [[ -n "${FL26_CPUSET:-}" ]]; then runner=(taskset -c "$FL26_CPUSET"); fi
"${runner[@]}" wine SiderAddons/sider.exe >"$ONLINE/logs/sider-latest.log" 2>&1 9>&- &
sider_pid=$!
trap 'kill "$sider_pid" 2>/dev/null || true' EXIT
"${runner[@]}" wine FL_2026.exe >"$ONLINE/logs/game-latest.log" 2>&1 9>&-
